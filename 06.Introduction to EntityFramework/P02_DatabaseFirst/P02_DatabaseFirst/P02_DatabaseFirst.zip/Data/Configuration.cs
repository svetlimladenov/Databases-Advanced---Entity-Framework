﻿namespace P02_DatabaseFirst.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-D8U60HB\SQLEXPRESS;Database=SoftUni;Integrated Security=True";
    }
}

