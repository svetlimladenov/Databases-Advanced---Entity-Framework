﻿namespace PetClinic.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-D8U60HB\SQLEXPRESS;Database=PetClinic;Trusted_Connection=True";
    }
}
