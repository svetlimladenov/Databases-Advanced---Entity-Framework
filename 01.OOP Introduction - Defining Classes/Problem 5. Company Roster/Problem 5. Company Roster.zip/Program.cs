﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5.Company_Roster
{
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
