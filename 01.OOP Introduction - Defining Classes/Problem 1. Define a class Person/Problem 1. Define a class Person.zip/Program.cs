﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.Define_a_class_Person
{
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
