﻿using System;
using Stations.Data;

namespace Stations.DataProcessor
{
	public class Serializer
	{
		public static string ExportDelayedTrains(StationsDbContext context, string dateAsString)
		{
			throw new NotImplementedException();
		}

		public static string ExportCardsTicket(StationsDbContext context, string cardType)
		{
			throw new NotImplementedException();
		}
	}
}