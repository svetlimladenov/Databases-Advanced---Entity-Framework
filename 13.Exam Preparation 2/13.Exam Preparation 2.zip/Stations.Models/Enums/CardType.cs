﻿namespace Stations.Models.Enums
{
    public enum CardType
    {
        Pupil,
        Student,
        Elder,
        Debilitated,
        Normal,
    }
}