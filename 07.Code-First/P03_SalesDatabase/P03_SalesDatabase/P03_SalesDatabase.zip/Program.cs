﻿using System;
using P03_SalesDatabase.Data;

namespace P03_SalesDatabase
{
    public class Program
    {
        public static void Main(string[] args)
        {
            using (var db = new SalesContext())
            {
                db.Database.EnsureCreated();
            }
        }
    }
}
