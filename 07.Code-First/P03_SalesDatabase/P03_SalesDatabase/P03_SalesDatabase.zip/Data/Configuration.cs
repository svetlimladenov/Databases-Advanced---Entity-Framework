﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public static string ConnectionString { get; set; } = @"Server=.;Database=Sales;Integrated Security=True";
    }
}
