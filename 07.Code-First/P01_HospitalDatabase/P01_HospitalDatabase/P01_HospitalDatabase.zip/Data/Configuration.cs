﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-D8U60HB\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
