﻿namespace BookShop.Data
{
    public class Configuration
    {
        public const string Connection = @"Server=DESKTOP-D8U60HB\SQLEXPRESS;Database=BookShop;Integrated Security=True";
    }
}
